import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Anemone class gives Clownfish a place to hide.
 * 
 * @author Paul Pollard 
 * @version 2/11/22
 */
public class Anemone extends Actor
{
    /**
     * Stands there. Menacingly!
     */
    public void act()
    {
        
    }
}
